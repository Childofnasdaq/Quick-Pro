import ProtectedLayout from "@/components/layouts/protected-layout"

export default function HelpPage() {
  return (
    <ProtectedLayout>
      <div className="mx-auto max-w-7xl">
        <h1 className="text-2xl font-bold">Help & Support</h1>
        {/* Add help content here */}
      </div>
    </ProtectedLayout>
  )
}

