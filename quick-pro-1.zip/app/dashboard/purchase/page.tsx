import ProtectedLayout from "@/components/layouts/protected-layout"

export default function PurchasePage() {
  return (
    <ProtectedLayout>
      <div className="mx-auto max-w-7xl">
        <h1 className="text-2xl font-bold">Purchase Keys</h1>
        {/* Add purchase form here */}
      </div>
    </ProtectedLayout>
  )
}

